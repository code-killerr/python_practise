easygui API
===================================


.. autosummary::

.. automodule:: easygui
   :members:
   :undoc-members:
   :show-inheritance:
   :platform: Unix, Windows, Interpreted
   :synopsis: an easy-to-use interface for simple GUI interaction
